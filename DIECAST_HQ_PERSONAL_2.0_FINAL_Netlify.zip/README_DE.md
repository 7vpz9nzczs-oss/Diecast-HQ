# DIECAST HQ — PERSONAL EDITION 2.0

## Was ist enthalten?
- Garage als Sammelkarten-Katalog, 38 Einträge DC-0001 bis DC-0038 (Stand 05.11.2026)
- Hunt-Wunschliste (offline; unabhängig von Besitz), Showroom mit persönlich ausgewählten Highlights, Insights
- Modell-Steckbriefe mit Fotos, Bearbeitung, Notizen, Provenienz und Low-/Real-/High-Arbeitswerten
- Offline-fähige iPhone-Web-App (PWA) ohne KI, ChatGPT-Login, Backend oder Drittanbieter-JavaScript
- Datenverwaltung: CSV-Export und Import/Update; komplettes JSON-Backup inkl. Fotos und Hunt-Liste
- Google Bilder / Web-Suche für einzelne Modelle: **nur externe Links**, Internet benötigt

## Installation auf deinem iPhone
1. Entpacke diese ZIP-Datei auf deinem Mac.
2. Öffne deine **bereits bestehende** Netlify-Website im Netlify-Dashboard. Benutze unbedingt **dieselbe Site / Domain** wie bisher.
3. Lade den **Inhalt des Ordners `site`** als neues Deployment hoch (Netlify Deploys → deploy manually; den Ordner `site` hineinziehen). Der Ordner `site` enthält `index.html` direkt im obersten Verzeichnis.
4. Öffne die bestehende `*.netlify.app`-Adresse einmal online in **Safari auf dem iPhone**.
5. Tippe **Teilen → Zum Home-Bildschirm** (je nach iOS-Version ggf. über „Mehr“). Danach DIECAST HQ über das App-Symbol öffnen.
6. Nach dem ersten Laden werden App-Inhalte lokal zwischengespeichert und sind offline nutzbar. Für Bildersuche / Web-Suche ist Internet erforderlich.

**Hinweis:** Die reine HTML-Datei aus dieser ZIP kann nicht als vollwertige PWA aus der Dateien-App installiert werden. Browser können Daten von `file://`-Dateien einschränken. Für den produktiven Betrieb die Netlify-Version verwenden.

## Datenhaltung / Updates
- Die Modellstammdaten sind im Browser-Speicher (`localStorage`), Fotos in der lokalen Browser-Fotodatenbank (`IndexedDB`) gespeichert.
- Die App nutzt für Modellstammdaten **denselben Speicher-Key** wie deine bisherigen Prototypen (`diecast_hq_demo_v1`) und für Fotos dieselbe IndexedDB (`diecast-hq-prototype`). So sollen bestehende lokale Einträge und Fotos beim Update übernommen werden.
- Ein Deployment auf **derselben Domain** setzt die vorhandenen Browserdaten nicht zurück. **Nicht** „Website-Daten löschen“, ein neues Browserprofil verwenden oder auf eine andere Domain wechseln, ohne vorher zu exportieren.
- iPhone-Home-Screen-Web-Apps und Safari können eigene Datenspeicher nutzen. Prüfe deshalb deine Sammlung **in der installierten App selbst**.
- Kein automatisches Cloud-Backup oder Sync zwischen iPhone und Mac. Verwende regelmäßig **Einstellungen → Datenbank, Import & Export → Komplettes Backup**.
- iOS kann Browser-Daten unter Umständen entfernen. Ein extern gespeichertes JSON-Backup ist daher wichtig.

## Backup und CSV für Excel
1. **Vollständiges JSON-Backup:** Modelle + Hunt + Showroom-Markierung + Fotos. Dateiname `DIECAST_HQ_VOLLBACKUP_YYYY-MM-DD.json`. Im Datenzentrum lässt es sich vollständig wiederherstellen; dabei ersetzt es die bestehende lokale Sammlung nach Bestätigung.
2. **CSV (Excel-kompatibel):** `DIECAST_HQ_Sammlung_YYYY-MM-DD.csv` mit Semikolon-Trennung und UTF-8. Einfach in Excel öffnen, Katalogfelder bearbeiten und als **CSV UTF-8** speichern. CSV enthält **keine Fotos** und **keine Hunt-Wunschliste**.
3. **CSV importieren:** Vorschau zeigt erkannte Zeilen und schon vorhandene DC-Nummern. Entweder nur unbekannte Exemplare ergänzen oder vorhandene Einträge **über DC-Nummer aktualisieren**. Bei Update werden nur **nicht-leere CSV-Felder** überschrieben; Fotos und nicht enthaltene Felder bleiben erhalten. Leere Zellen löschen bestehende Daten **nicht**.
4. **Wiederherstellen:** Alte JSON-Backups aus Personal Edition 2.0 und vom Prototyp v1.2 (`diecast-hq-prototype-1`) werden akzeptiert.
5. Beim Update der App am besten immer zuerst ein JSON-Backup herunterladen und in iCloud Drive / Dateien / auf dem Mac sichern.

**Wichtig:** Die CSV im ZIP (`DIECAST_HQ_Excel_Startbestand_38.csv`) ist der ursprüngliche Startbestand – nicht die spätere Live-Sammlung. Bearbeite künftig bevorzugt deine **frisch aus der App exportierte CSV**.

## Datenschutz und Grenzen
- Die App übermittelt private, nachträglich hinzugefügte Fotos oder Inventardaten **nicht** an Netlify / OpenAI. Es gibt keine KI-Anbindung.
- Die ursprünglich mitgelieferten 38 Katalogeinträge sind als Bestandteil der statischen Website aber **auf dem Hosting-Server enthalten**. Bei einer öffentlich erreichbaren Netlify-URL sind diese Startdaten technisch abrufbar. Für echte Zugriffsbeschränkung ist zusätzlich geschütztes Hosting erforderlich.
- Google-Suche öffnet Safari und übermittelt die Suchbegriffe erst nach deinem Tippen.
- Eine Web-App ist kein natives iOS-Binary. Offline-Funktion und Kamera-/Speicherverhalten können von iOS- und Safari-Version sowie den Datenschutzeinstellungen abhängen.

## Dateien
- `site/` – vollständig eigenständige statische iPhone-App, bereit zum Netlify-Deployment
- `DIECAST_HQ_Excel_Startbestand_38.csv` – ursprüngliche Excel-kompatible Datenbasis zum Nachvollziehen
- `README_DE.md` – diese Anleitung

Version: DIECAST HQ Personal 2.0 · 07.11.2026.
